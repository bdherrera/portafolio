-- =====================================================================
-- Bases de Datos 2 · Taller integrador — MercaAndes
-- 00_setup.sql   Creación del esquema y carga de datos
--
-- Lo ejecuta CADA PAREJA UNA SOLA VEZ, en UNA de sus dos conexiones.
-- Ejecútelo completo con "Run Script" (F5), NO con Ctrl+Enter.
--
-- Tarda entre 2 y 4 minutos. Mientras corre, lea el enunciado.
-- =====================================================================

SET SERVEROUTPUT ON
SET TIMING ON
SET LINESIZE 200
SET PAGESIZE 100

-- ---------------------------------------------------------------------
-- 0. ¿En qué sesión estoy?  Ejecute esto en LAS DOS conexiones.
--    Los dos números deben ser DISTINTOS. Si son iguales, no tiene dos
--    sesiones: abrió dos hojas de trabajo sobre la misma conexión.
-- ---------------------------------------------------------------------
SELECT USER                                  AS usuario,
       SYS_CONTEXT('USERENV','SID')          AS sid,
       SYS_CONTEXT('USERENV','SERVICE_NAME') AS servicio
  FROM dual;

-- ---------------------------------------------------------------------
-- 1. Limpieza previa
--    Si es la primera vez que ejecuta el taller, estas diez sentencias
--    van a devolver ORA-00942: table or view does not exist.
--    Es normal, ignórelo y siga.
-- ---------------------------------------------------------------------
DROP TABLE ajuste_inventario CASCADE CONSTRAINTS PURGE;
DROP TABLE tarea_despacho   CASCADE CONSTRAINTS PURGE;
DROP TABLE pago             CASCADE CONSTRAINTS PURGE;
DROP TABLE pedido_detalle   CASCADE CONSTRAINTS PURGE;
DROP TABLE pedido           CASCADE CONSTRAINTS PURGE;
DROP TABLE inventario       CASCADE CONSTRAINTS PURGE;
DROP TABLE producto         CASCADE CONSTRAINTS PURGE;
DROP TABLE categoria        CASCADE CONSTRAINTS PURGE;
DROP TABLE bodega           CASCADE CONSTRAINTS PURGE;
DROP TABLE cliente          CASCADE CONSTRAINTS PURGE;

-- ---------------------------------------------------------------------
-- 2. Estructura
-- ---------------------------------------------------------------------

-- Jerarquía de categorías (3 niveles) -> se usa en la CTE recursiva
CREATE TABLE categoria (
  id_categoria  NUMBER        NOT NULL,
  nombre        VARCHAR2(40)  NOT NULL,
  id_padre      NUMBER,
  CONSTRAINT pk_categoria PRIMARY KEY (id_categoria),
  CONSTRAINT fk_cat_padre FOREIGN KEY (id_padre) REFERENCES categoria
);

CREATE TABLE bodega (
  id_bodega   NUMBER        NOT NULL,
  ciudad      VARCHAR2(30)  NOT NULL,
  CONSTRAINT pk_bodega PRIMARY KEY (id_bodega)
);

CREATE TABLE producto (
  id_producto   NUMBER        NOT NULL,
  sku           VARCHAR2(20)  NOT NULL,
  nombre        VARCHAR2(80)  NOT NULL,
  id_categoria  NUMBER        NOT NULL,
  precio        NUMBER(12,2)  NOT NULL,
  activo        CHAR(1)       DEFAULT 'S' NOT NULL,
  CONSTRAINT pk_producto  PRIMARY KEY (id_producto),
  CONSTRAINT uk_producto_sku UNIQUE (sku),
  CONSTRAINT fk_prod_cat  FOREIGN KEY (id_categoria) REFERENCES categoria,
  CONSTRAINT ck_prod_act  CHECK (activo IN ('S','N'))
);

-- OJO: la columna VERSION existe para el ejercicio de bloqueo optimista
CREATE TABLE inventario (
  id_producto   NUMBER   NOT NULL,
  id_bodega     NUMBER   NOT NULL,
  disponible    NUMBER   NOT NULL,
  reservado     NUMBER   DEFAULT 0 NOT NULL,
  version       NUMBER   DEFAULT 0 NOT NULL,
  CONSTRAINT pk_inventario PRIMARY KEY (id_producto, id_bodega),
  CONSTRAINT fk_inv_prod   FOREIGN KEY (id_producto) REFERENCES producto,
  CONSTRAINT fk_inv_bod    FOREIGN KEY (id_bodega)   REFERENCES bodega,
  CONSTRAINT ck_inv_disp   CHECK (disponible >= 0)
);

CREATE TABLE cliente (
  id_cliente      NUMBER        NOT NULL,
  nombre          VARCHAR2(60)  NOT NULL,
  ciudad          VARCHAR2(30)  NOT NULL,
  segmento        VARCHAR2(12)  NOT NULL,
  fecha_registro  DATE          NOT NULL,
  CONSTRAINT pk_cliente PRIMARY KEY (id_cliente)
);

CREATE TABLE pedido (
  id_pedido     NUMBER        NOT NULL,
  id_cliente    NUMBER        NOT NULL,
  fecha_pedido  DATE          NOT NULL,
  estado        VARCHAR2(12)  NOT NULL,
  canal         VARCHAR2(10)  NOT NULL,
  total         NUMBER(14,2),
  CONSTRAINT pk_pedido    PRIMARY KEY (id_pedido),
  CONSTRAINT fk_ped_cli   FOREIGN KEY (id_cliente) REFERENCES cliente,
  CONSTRAINT ck_ped_est   CHECK (estado IN ('CREADO','PAGADO','DESPACHADO','ENTREGADO','ANULADO'))
);

CREATE TABLE pedido_detalle (
  id_pedido     NUMBER        NOT NULL,
  linea         NUMBER        NOT NULL,
  id_producto   NUMBER        NOT NULL,
  cantidad      NUMBER        NOT NULL,
  precio_unit   NUMBER(12,2)  NOT NULL,
  CONSTRAINT pk_pedido_det  PRIMARY KEY (id_pedido, linea),
  CONSTRAINT fk_det_ped     FOREIGN KEY (id_pedido)   REFERENCES pedido,
  CONSTRAINT fk_det_prod    FOREIGN KEY (id_producto) REFERENCES producto
);

-- OJO: la llave foránea PAGO.ID_PEDIDO queda SIN ÍNDICE a propósito.
--      En el ejercicio 1.5 vamos a ver qué provoca eso.
CREATE TABLE pago (
  id_pago     NUMBER        NOT NULL,
  id_pedido   NUMBER        NOT NULL,
  fecha_pago  DATE          NOT NULL,
  valor       NUMBER(14,2)  NOT NULL,
  estado      VARCHAR2(12)  NOT NULL,
  CONSTRAINT pk_pago     PRIMARY KEY (id_pago),
  CONSTRAINT fk_pago_ped FOREIGN KEY (id_pedido) REFERENCES pedido
);

-- Cola de trabajo -> se usa en el ejercicio de SKIP LOCKED
CREATE TABLE tarea_despacho (
  id_tarea     NUMBER        NOT NULL,
  id_pedido    NUMBER        NOT NULL,
  estado       VARCHAR2(12)  DEFAULT 'PENDIENTE' NOT NULL,
  tomada_por   VARCHAR2(20),
  fecha_toma   TIMESTAMP,
  CONSTRAINT pk_tarea PRIMARY KEY (id_tarea)
);

-- Tabla de ajustes -> se usa en el ejercicio de MERGE
CREATE TABLE ajuste_inventario (
  id_producto  NUMBER  NOT NULL,
  id_bodega    NUMBER  NOT NULL,
  delta        NUMBER  NOT NULL,
  motivo       VARCHAR2(30) NOT NULL
);

-- ---------------------------------------------------------------------
-- 3. Datos maestros
-- ---------------------------------------------------------------------

-- Nivel 1
INSERT INTO categoria VALUES (1,  'Tecnología',        NULL);
INSERT INTO categoria VALUES (2,  'Hogar',             NULL);
INSERT INTO categoria VALUES (3,  'Deportes',          NULL);
-- Nivel 2
INSERT INTO categoria VALUES (10, 'Computación',       1);
INSERT INTO categoria VALUES (11, 'Audio y video',     1);
INSERT INTO categoria VALUES (12, 'Telefonía',         1);
INSERT INTO categoria VALUES (13, 'Cocina',            2);
INSERT INTO categoria VALUES (14, 'Muebles',           2);
INSERT INTO categoria VALUES (15, 'Ciclismo',          3);
INSERT INTO categoria VALUES (16, 'Fitness',           3);
-- Nivel 3
INSERT INTO categoria VALUES (100,'Portátiles',        10);
INSERT INTO categoria VALUES (101,'Periféricos',       10);
INSERT INTO categoria VALUES (102,'Monitores',         10);
INSERT INTO categoria VALUES (103,'Audífonos',         11);
INSERT INTO categoria VALUES (104,'Parlantes',         11);
INSERT INTO categoria VALUES (105,'Smartphones',       12);
INSERT INTO categoria VALUES (106,'Electrodomésticos', 13);
INSERT INTO categoria VALUES (107,'Ollas y sartenes',  13);
INSERT INTO categoria VALUES (108,'Bicicletas',        15);
INSERT INTO categoria VALUES (109,'Pesas',             16);
COMMIT;

INSERT INTO bodega VALUES (1,'Bogotá');
INSERT INTO bodega VALUES (2,'Medellín');
INSERT INTO bodega VALUES (3,'Cali');
INSERT INTO bodega VALUES (4,'Barranquilla');
INSERT INTO bodega VALUES (5,'Bucaramanga');
COMMIT;

-- 5.000 productos, repartidos entre las categorías hoja
INSERT /*+ APPEND */ INTO producto (id_producto, sku, nombre, id_categoria, precio, activo)
SELECT n,
       'SKU-'||LPAD(n,6,'0'),
       CASE MOD(n,10)
         WHEN 0 THEN 'Portátil'      WHEN 1 THEN 'Teclado mecánico'
         WHEN 2 THEN 'Monitor'       WHEN 3 THEN 'Audífonos'
         WHEN 4 THEN 'Parlante'      WHEN 5 THEN 'Smartphone'
         WHEN 6 THEN 'Licuadora'     WHEN 7 THEN 'Sartén'
         WHEN 8 THEN 'Bicicleta'     ELSE      'Mancuerna'
       END || ' modelo ' || n,
       100 + MOD(n,10),
       ROUND(DBMS_RANDOM.VALUE(20000, 4500000), -2),
       CASE WHEN MOD(n,37) = 0 THEN 'N' ELSE 'S' END
  FROM (SELECT LEVEL n FROM dual CONNECT BY LEVEL <= 5000);
COMMIT;

-- Inventario: cada producto en las 5 bodegas
INSERT /*+ APPEND */ INTO inventario (id_producto, id_bodega, disponible, reservado, version)
SELECT p.id_producto, b.id_bodega,
       TRUNC(DBMS_RANDOM.VALUE(0, 400)), 0, 0
  FROM producto p CROSS JOIN bodega b;
COMMIT;

-- Producto y bodega de laboratorio para los ejercicios de concurrencia:
-- valores conocidos, para que todos vean lo mismo.
UPDATE inventario SET disponible = 10, reservado = 0, version = 0
 WHERE id_producto IN (100, 200) AND id_bodega = 1;
COMMIT;

-- 20.000 clientes
INSERT /*+ APPEND */ INTO cliente (id_cliente, nombre, ciudad, segmento, fecha_registro)
SELECT n,
       'Cliente '||n,
       CASE MOD(n,6) WHEN 0 THEN 'Bogotá'   WHEN 1 THEN 'Medellín'
                     WHEN 2 THEN 'Cali'     WHEN 3 THEN 'Barranquilla'
                     WHEN 4 THEN 'Pereira'  ELSE 'Bucaramanga' END,
       CASE MOD(n,10) WHEN 0 THEN 'PREMIUM' WHEN 1 THEN 'PREMIUM'
                      WHEN 2 THEN 'PYME'    ELSE 'ESTANDAR' END,
       DATE '2024-01-01' + MOD(n, 700)
  FROM (SELECT LEVEL n FROM dual CONNECT BY LEVEL <= 20000);
COMMIT;

-- 200.000 pedidos repartidos en 2 años
INSERT /*+ APPEND */ INTO pedido (id_pedido, id_cliente, fecha_pedido, estado, canal, total)
SELECT n,
       MOD(n, 20000) + 1,
       DATE '2025-01-01' + MOD(n * 7, 730) + (MOD(n,24)/24),
       CASE
         WHEN MOD(n,100) < 62 THEN 'ENTREGADO'
         WHEN MOD(n,100) < 80 THEN 'DESPACHADO'
         WHEN MOD(n,100) < 92 THEN 'PAGADO'
         WHEN MOD(n,100) < 98 THEN 'CREADO'
         ELSE 'ANULADO'
       END,
       CASE MOD(n,4) WHEN 0 THEN 'WEB' WHEN 1 THEN 'APP'
                     WHEN 2 THEN 'WEB' ELSE 'CALLCENTER' END,
       NULL
  FROM (SELECT LEVEL n FROM dual CONNECT BY LEVEL <= 200000);
COMMIT;

-- Detalle: entre 1 y 3 líneas por pedido  (~400.000 filas)
INSERT /*+ APPEND */ INTO pedido_detalle (id_pedido, linea, id_producto, cantidad, precio_unit)
SELECT p.id_pedido,
       l.lin,
       MOD(p.id_pedido * l.lin, 5000) + 1,
       MOD(p.id_pedido + l.lin, 4) + 1,
       pr.precio
  FROM pedido p
  CROSS JOIN (SELECT LEVEL lin FROM dual CONNECT BY LEVEL <= 3) l
  JOIN producto pr ON pr.id_producto = MOD(p.id_pedido * l.lin, 5000) + 1
 WHERE l.lin <= MOD(p.id_pedido, 3) + 1;
COMMIT;

-- Total del pedido a partir del detalle
MERGE INTO pedido p
USING (SELECT id_pedido, SUM(cantidad * precio_unit) AS t
         FROM pedido_detalle GROUP BY id_pedido) d
   ON (p.id_pedido = d.id_pedido)
 WHEN MATCHED THEN UPDATE SET p.total = d.t;
COMMIT;

-- Pagos: solo los pedidos que pasaron de CREADO
INSERT /*+ APPEND */ INTO pago (id_pago, id_pedido, fecha_pago, valor, estado)
SELECT ROWNUM, id_pedido, fecha_pedido + 1, total, 'APROBADO'
  FROM pedido
 WHERE estado IN ('PAGADO','DESPACHADO','ENTREGADO');
COMMIT;

-- Pedidos de laboratorio SIN detalle y SIN pago, para el ejercicio 1.5
INSERT INTO pedido (id_pedido, id_cliente, fecha_pedido, estado, canal, total)
SELECT 900000 + LEVEL, 1, SYSDATE, 'CREADO', 'WEB', 0
  FROM dual CONNECT BY LEVEL <= 10;
COMMIT;

-- Pedido de laboratorio para el RETO (parte 4).
-- Dos líneas con valores conocidos: producto 100 x3 y producto 200 x2.
-- No se genera al azar porque el enunciado del reto depende de estos valores.
INSERT INTO pedido (id_pedido, id_cliente, fecha_pedido, estado, canal, total)
VALUES (950001, 1, SYSDATE, 'CREADO', 'WEB', 0);

INSERT INTO pedido_detalle (id_pedido, linea, id_producto, cantidad, precio_unit)
SELECT 950001, 1, 100, 3, precio FROM producto WHERE id_producto = 100;

INSERT INTO pedido_detalle (id_pedido, linea, id_producto, cantidad, precio_unit)
SELECT 950001, 2, 200, 2, precio FROM producto WHERE id_producto = 200;

UPDATE pedido
   SET total = (SELECT SUM(cantidad * precio_unit)
                  FROM pedido_detalle WHERE id_pedido = 950001)
 WHERE id_pedido = 950001;
COMMIT;

-- Cola de despacho
INSERT INTO tarea_despacho (id_tarea, id_pedido, estado)
SELECT LEVEL, LEVEL, 'PENDIENTE' FROM dual CONNECT BY LEVEL <= 200;
COMMIT;

-- Ajustes de inventario para el MERGE
INSERT INTO ajuste_inventario (id_producto, id_bodega, delta, motivo)
SELECT MOD(LEVEL * 13, 5000) + 1,
       MOD(LEVEL, 5) + 1,
       CASE WHEN MOD(LEVEL,3) = 0 THEN -5 ELSE 25 END,
       CASE WHEN MOD(LEVEL,3) = 0 THEN 'MERMA' ELSE 'INGRESO' END
  FROM dual CONNECT BY LEVEL <= 500;
COMMIT;

-- ---------------------------------------------------------------------
-- 4. Estadísticas
--    Sin estadísticas frescas el optimizador adivina y los planes que
--    van a leer no significan nada.
-- ---------------------------------------------------------------------
EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'CATEGORIA',      cascade => TRUE);
EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'BODEGA',         cascade => TRUE);
EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'PRODUCTO',       cascade => TRUE);
EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'INVENTARIO',     cascade => TRUE);
EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'CLIENTE',        cascade => TRUE);
EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'PEDIDO',         cascade => TRUE);
EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'PEDIDO_DETALLE', cascade => TRUE);
EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'PAGO',           cascade => TRUE);
EXEC DBMS_STATS.GATHER_TABLE_STATS(USER, 'TAREA_DESPACHO', cascade => TRUE);

-- ---------------------------------------------------------------------
-- 5. Verificación — anote estos números
-- ---------------------------------------------------------------------
SELECT 'CATEGORIA'       AS tabla, COUNT(*) AS filas FROM categoria
UNION ALL SELECT 'PRODUCTO',        COUNT(*) FROM producto
UNION ALL SELECT 'INVENTARIO',      COUNT(*) FROM inventario
UNION ALL SELECT 'CLIENTE',         COUNT(*) FROM cliente
UNION ALL SELECT 'PEDIDO',          COUNT(*) FROM pedido
UNION ALL SELECT 'PEDIDO_DETALLE',  COUNT(*) FROM pedido_detalle
UNION ALL SELECT 'PAGO',            COUNT(*) FROM pago
UNION ALL SELECT 'TAREA_DESPACHO',  COUNT(*) FROM tarea_despacho;

-- Índices que existen en este momento: SOLO los de las restricciones.
-- Todo lo demás lo van a crear ustedes, y van a justificar por qué.
SELECT table_name, index_name, uniqueness
  FROM user_indexes ORDER BY table_name, index_name;

-- El pedido que usa el reto de la parte 4: debe tener exactamente dos
-- líneas, producto 100 con 3 unidades y producto 200 con 2 unidades.
SELECT d.id_pedido, d.linea, d.id_producto, d.cantidad, i.disponible
  FROM pedido_detalle d
  JOIN inventario i ON i.id_producto = d.id_producto AND i.id_bodega = 1
 WHERE d.id_pedido = 950001
 ORDER BY d.linea;

PROMPT
PROMPT ======================================================================
PROMPT  Esquema MercaAndes listo.
PROMPT  Abra la SEGUNDA conexión y verifique que el SID sea distinto.
PROMPT  Continúe con 01_sesion_A.sql y 01_sesion_B.sql
PROMPT ======================================================================
