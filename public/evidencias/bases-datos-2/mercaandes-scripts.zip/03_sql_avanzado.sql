-- =====================================================================
-- Bases de Datos 2 · Taller integrador — MercaAndes
-- 03_sql_avanzado.sql   SQL analítico, jerárquico y MERGE
--
-- Trabajen en UNA SOLA CONEXIÓN: la pareja comparte el esquema.
-- Cada bloque trae una consulta RESUELTA que sirve de modelo, y una
-- consulta que ustedes deben ESCRIBIR. Complete las que dicen ESCRIBA.
-- =====================================================================

SET LINESIZE 220
SET PAGESIZE 60
SET TIMING ON


-- #####################################################################
-- EJERCICIO 3.1 — Ranking dentro de grupos
--
-- Comercial quiere los 3 productos que más facturaron en cada categoría
-- durante 2026, solo contando pedidos que no fueron anulados.
-- #####################################################################

-- MODELO (resuelto)
WITH ventas AS (
  SELECT pr.id_categoria,
         pr.id_producto,
         pr.nombre,
         SUM(d.cantidad * d.precio_unit) AS facturado
    FROM pedido p
    JOIN pedido_detalle d ON d.id_pedido   = p.id_pedido
    JOIN producto       pr ON pr.id_producto = d.id_producto
   WHERE p.fecha_pedido >= DATE '2026-01-01'
     AND p.fecha_pedido <  DATE '2027-01-01'
     AND p.estado <> 'ANULADO'
   GROUP BY pr.id_categoria, pr.id_producto, pr.nombre
)
SELECT id_categoria, nombre, facturado, puesto
  FROM (SELECT v.*,
               DENSE_RANK() OVER (PARTITION BY id_categoria
                                  ORDER BY facturado DESC) AS puesto
          FROM ventas v)
 WHERE puesto <= 3
 ORDER BY id_categoria, puesto;

--
--  PREGUNTA 3.1 — Cambie DENSE_RANK por RANK y luego por ROW_NUMBER.
--  Explique en qué se diferencian los tres cuando hay empates, y cuál
--  usaría usted para un "top 3" que debe devolver exactamente 3 filas.
--
--  ESCRIBA 3.1 — La misma consulta, pero mostrando además qué porcentaje
--  representa cada producto sobre el total facturado de su categoría.
--  Use RATIO_TO_REPORT o una función de ventana con SUM() OVER.


-- #####################################################################
-- EJERCICIO 3.2 — Series de tiempo: acumulado y variación
--
-- Gerencia quiere la evolución mensual de ventas de 2026, con el
-- acumulado del año y el crecimiento contra el mes anterior.
-- #####################################################################

-- MODELO (resuelto)
WITH mensual AS (
  SELECT TRUNC(fecha_pedido, 'MM') AS mes,
         SUM(total)                AS ventas,
         COUNT(*)                  AS pedidos
    FROM pedido
   WHERE fecha_pedido >= DATE '2026-01-01'
     AND fecha_pedido <  DATE '2027-01-01'
     AND estado <> 'ANULADO'
   GROUP BY TRUNC(fecha_pedido, 'MM')
)
SELECT TO_CHAR(mes,'YYYY-MM')                          AS mes,
       pedidos,
       ROUND(ventas)                                   AS ventas,
       ROUND(SUM(ventas) OVER (ORDER BY mes
             ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)) AS acumulado,
       ROUND(LAG(ventas) OVER (ORDER BY mes))          AS mes_anterior,
       ROUND(100 * (ventas - LAG(ventas) OVER (ORDER BY mes))
                 / NULLIF(LAG(ventas) OVER (ORDER BY mes),0), 1) AS var_pct
  FROM mensual
 ORDER BY mes;

--
--  PREGUNTA 3.2 — ¿Qué diferencia hay entre
--     ROWS  BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
--  y  RANGE BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW ?
--  Constrúyase un caso donde den resultados distintos.
--
--  ESCRIBA 3.2 — Agregue una columna con el promedio móvil de los
--  últimos 3 meses (mes actual y los dos anteriores).


-- #####################################################################
-- EJERCICIO 3.3 — La misma respuesta, dos planes muy distintos
--
-- Se necesita, por cada cliente PREMIUM, su último pedido.
-- #####################################################################

-- VERSIÓN A — subconsulta correlacionada  (la que sale sola al escribir)
EXPLAIN PLAN FOR
SELECT c.id_cliente, c.nombre, p.id_pedido, p.fecha_pedido, p.total
  FROM cliente c
  JOIN pedido  p ON p.id_cliente = c.id_cliente
 WHERE c.segmento = 'PREMIUM'
   AND p.fecha_pedido = (SELECT MAX(p2.fecha_pedido)
                           FROM pedido p2
                          WHERE p2.id_cliente = c.id_cliente);

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST +ROWS'));

-- VERSIÓN B — función analítica
EXPLAIN PLAN FOR
SELECT id_cliente, nombre, id_pedido, fecha_pedido, total
  FROM (SELECT c.id_cliente, c.nombre, p.id_pedido, p.fecha_pedido, p.total,
               ROW_NUMBER() OVER (PARTITION BY c.id_cliente
                                  ORDER BY p.fecha_pedido DESC) AS rn
          FROM cliente c
          JOIN pedido  p ON p.id_cliente = c.id_cliente
         WHERE c.segmento = 'PREMIUM')
 WHERE rn = 1;

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'BASIC +COST +ROWS'));

--
--  PREGUNTA 3.3 — Compare los dos planes. ¿Cuántas veces se lee PEDIDO
--  en cada versión? ¿Cuál es el COST de cada una?
--
--  PREGUNTA 3.4 — Las dos consultas NO son totalmente equivalentes:
--  hay un caso en el que devuelven distinto número de filas. ¿Cuál es?
--  (pista: piense en dos pedidos del mismo cliente el mismo día)


-- #####################################################################
-- EJERCICIO 3.4 — Jerarquías: la CTE recursiva
--
-- El catálogo tiene categorías anidadas en tres niveles.
-- #####################################################################

-- MODELO (resuelto) — ruta completa de cada categoría
WITH arbol (id_categoria, nombre, id_padre, nivel, ruta) AS (
  SELECT id_categoria, nombre, id_padre, 1, CAST(nombre AS VARCHAR2(400))
    FROM categoria
   WHERE id_padre IS NULL
  UNION ALL
  SELECT c.id_categoria, c.nombre, c.id_padre, a.nivel + 1,
         a.ruta || ' > ' || c.nombre
    FROM categoria c
    JOIN arbol a ON c.id_padre = a.id_categoria
)
SELECT LPAD(' ', (nivel-1)*3) || nombre AS jerarquia, nivel, ruta
  FROM arbol
 ORDER BY ruta;

-- El equivalente con CONNECT BY, sintaxis propia de Oracle
SELECT LPAD(' ', (LEVEL-1)*3) || nombre AS jerarquia,
       LEVEL AS nivel,
       SYS_CONNECT_BY_PATH(nombre, ' > ') AS ruta
  FROM categoria
 START WITH id_padre IS NULL
CONNECT BY PRIOR id_categoria = id_padre
 ORDER SIBLINGS BY nombre;

--
--  PREGUNTA 3.5 — ¿Qué ventaja tiene la CTE recursiva sobre CONNECT BY?
--  ¿Y qué le da CONNECT BY que la CTE no?
--
--  ESCRIBA 3.3 — Facturación total de 2026 por categoría RAÍZ.
--  Es decir: las ventas de "Portátiles" deben sumar dentro de
--  "Tecnología". Use la CTE recursiva para resolver a qué raíz pertenece
--  cada categoría hoja, y únala con las ventas.


-- #####################################################################
-- EJERCICIO 3.5 — MERGE: aplicar los ajustes de inventario
--
-- Bodega envía cada noche un archivo de ajustes: mermas e ingresos.
-- La tabla AJUSTE_INVENTARIO ya los tiene cargados.
-- #####################################################################

-- PASO 1  Antes
SELECT SUM(disponible) AS stock_total FROM inventario;
SELECT motivo, COUNT(*), SUM(delta) FROM ajuste_inventario GROUP BY motivo;

-- MODELO (resuelto)
MERGE INTO inventario i
USING (SELECT id_producto, id_bodega, SUM(delta) AS delta
         FROM ajuste_inventario
        GROUP BY id_producto, id_bodega) a
   ON (i.id_producto = a.id_producto AND i.id_bodega = a.id_bodega)
 WHEN MATCHED THEN
   UPDATE SET i.disponible = GREATEST(i.disponible + a.delta, 0),
              i.version    = i.version + 1
 WHEN NOT MATCHED THEN
   INSERT (i.id_producto, i.id_bodega, i.disponible, i.reservado, i.version)
   VALUES (a.id_producto, a.id_bodega, GREATEST(a.delta,0), 0, 0);

--> Mire el mensaje de SQL Developer: cuántas filas fusionó.
COMMIT;

-- PASO 2  Después
SELECT SUM(disponible) AS stock_total FROM inventario;

--
--  PREGUNTA 3.6 — ¿Por qué se agrupa la tabla de ajustes dentro del
--  USING en lugar de usarla directamente? ¿Qué error da Oracle si un
--  mismo (producto, bodega) aparece dos veces en el origen?
--
--  PREGUNTA 3.7 — El GREATEST(..., 0) evita que el stock quede negativo.
--  ¿Es esa la forma correcta de resolverlo, o está escondiendo un
--  problema? ¿Qué haría usted en un sistema real?
--
--  ESCRIBA 3.4 — Modifique el MERGE para que además registre en la
--  cláusula WHEN MATCHED ... DELETE las filas de inventario que queden
--  en cero y estén en una bodega distinta de la 1.


-- #####################################################################
-- EJERCICIO 3.6 — PIVOT y LISTAGG
-- #####################################################################

-- MODELO (resuelto) — ventas por canal y trimestre, en columnas
SELECT *
  FROM (SELECT canal,
               'T' || TO_CHAR(fecha_pedido,'Q') AS trimestre,
               total
          FROM pedido
         WHERE fecha_pedido >= DATE '2026-01-01'
           AND fecha_pedido <  DATE '2027-01-01'
           AND estado <> 'ANULADO')
 PIVOT (ROUND(SUM(total)) FOR trimestre IN ('T1' AS t1, 'T2' AS t2,
                                            'T3' AS t3, 'T4' AS t4))
 ORDER BY canal;

-- MODELO (resuelto) — los 10 mejores clientes y qué categorías compraron
SELECT c.id_cliente, c.nombre,
       ROUND(SUM(d.cantidad * d.precio_unit)) AS facturado,
       LISTAGG(DISTINCT cat.nombre, ', ')
         WITHIN GROUP (ORDER BY cat.nombre) AS categorias
  FROM cliente c
  JOIN pedido         p   ON p.id_cliente   = c.id_cliente
  JOIN pedido_detalle d   ON d.id_pedido    = p.id_pedido
  JOIN producto       pr  ON pr.id_producto = d.id_producto
  JOIN categoria      cat ON cat.id_categoria = pr.id_categoria
 WHERE p.estado <> 'ANULADO'
 GROUP BY c.id_cliente, c.nombre
 ORDER BY facturado DESC
 FETCH FIRST 10 ROWS WITH TIES;

--
--  PREGUNTA 3.8 — ¿Qué diferencia hay entre FETCH FIRST 10 ROWS ONLY y
--  FETCH FIRST 10 ROWS WITH TIES? ¿En cuál de los dos casos puede
--  devolver más de 10 filas y por qué?
--
--  ESCRIBA 3.5 — Un informe de "clientes en riesgo": clientes PREMIUM
--  cuyo último pedido tiene más de 120 días, mostrando cuántos días
--  llevan sin comprar y cuánto facturaron históricamente.
