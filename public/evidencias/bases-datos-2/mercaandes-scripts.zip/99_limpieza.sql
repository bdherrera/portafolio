-- =====================================================================
-- Bases de Datos 2 · Taller integrador — MercaAndes
-- 99_limpieza.sql   Ejecutar al finalizar la sesión
-- =====================================================================

-- Cierre cualquier transacción abierta antes de limpiar
ROLLBACK;

DROP TABLE ajuste_inventario CASCADE CONSTRAINTS PURGE;
DROP TABLE tarea_despacho   CASCADE CONSTRAINTS PURGE;
DROP TABLE pago             CASCADE CONSTRAINTS PURGE;
DROP TABLE pedido_detalle   CASCADE CONSTRAINTS PURGE;
DROP TABLE pedido           CASCADE CONSTRAINTS PURGE;
DROP TABLE inventario       CASCADE CONSTRAINTS PURGE;
DROP TABLE producto         CASCADE CONSTRAINTS PURGE;
DROP TABLE categoria        CASCADE CONSTRAINTS PURGE;
DROP TABLE bodega           CASCADE CONSTRAINTS PURGE;
DROP TABLE cliente          CASCADE CONSTRAINTS PURGE;

PURGE RECYCLEBIN;

SELECT table_name FROM user_tables ORDER BY 1;

PROMPT
PROMPT  Esquema limpio. Espacio liberado.
