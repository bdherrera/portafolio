-- =====================================================================
-- Bases de Datos 2 · Taller integrador — MercaAndes
-- 04_reto.sql   Reto final (25 minutos)
--
-- Trabajen en UNA SOLA CONEXIÓN: la pareja comparte el esquema.
-- Este es el ejercicio que se entrega. Trabajen en pareja.
-- Todo se resuelve con SQL. No se necesita PL/SQL.
-- =====================================================================

-- ---------------------------------------------------------------------
-- EL TICKET
--
--   De:    Jefe de Operaciones, MercaAndes
--   Para:  Equipo de Base de Datos
--   Asunto: URGENTE — problemas en confirmación de pedidos
--
--   "Tenemos tres problemas desde el Black Friday:
--
--    1. Estamos vendiendo más unidades de las que hay en bodega. El
--       inventario del sistema no coincide con el físico y ya nos tocó
--       cancelar 40 pedidos.
--
--    2. Cuando la confirmación falla a la mitad, quedan pedidos en
--       estado PAGADO con el inventario ya descontado, o al revés.
--       Nadie sabe cuáles.
--
--    3. El tablero de la gerencia se demora casi un minuto en abrir.
--
--    Adjunto la secuencia de sentencias que ejecuta la aplicación cada
--    vez que un cliente paga, y la consulta del tablero. Necesitamos un
--    diagnóstico y la corrección."
-- ---------------------------------------------------------------------


-- #####################################################################
-- PIEZA 1 — Lo que ejecuta la aplicación al confirmar un pedido
--
-- La aplicación arma este bloque de sentencias en tiempo de ejecución,
-- una por cada línea del pedido, y las manda en este orden.
-- Aquí está el caso real del pedido 950001, que tiene dos líneas:
-- el producto 100 con 3 unidades y el producto 200 con 2 unidades.
--
-- Ejecútelo tal como está y observe qué hace. NO lo corrija todavía.
-- #####################################################################

-- Deje el inventario en un valor conocido antes de probar
UPDATE inventario SET disponible = 10 WHERE id_producto IN (100,200) AND id_bodega = 1;
UPDATE pedido SET estado = 'CREADO' WHERE id_pedido = 950001;
COMMIT;


--- inicio de lo que ejecuta la aplicación -----------------------------

-- línea 1 del pedido: producto 100, 3 unidades
SELECT disponible FROM inventario WHERE id_producto = 100 AND id_bodega = 1;
--> la aplicación guarda ese número, le resta 3, y escribe el resultado:
UPDATE inventario SET disponible = 7 WHERE id_producto = 100 AND id_bodega = 1;
COMMIT;

-- línea 2 del pedido: producto 200, 2 unidades
SELECT disponible FROM inventario WHERE id_producto = 200 AND id_bodega = 1;
--> la aplicación guarda ese número, le resta 2, y escribe el resultado:
UPDATE inventario SET disponible = 8 WHERE id_producto = 200 AND id_bodega = 1;
COMMIT;

-- y al final marca el pedido
UPDATE pedido SET estado = 'PAGADO' WHERE id_pedido = 950001;
COMMIT;

--- fin de lo que ejecuta la aplicación --------------------------------


-- #####################################################################
-- PIEZA 2 — La consulta del tablero de gerencia
-- #####################################################################

SELECT c.ciudad,
       COUNT(DISTINCT p.id_pedido)              AS pedidos,
       ROUND(SUM(d.cantidad * d.precio_unit))   AS facturado,
       ROUND(AVG(p.total))                      AS ticket
  FROM pedido         p
  JOIN cliente        c ON c.id_cliente  = p.id_cliente
  JOIN pedido_detalle d ON d.id_pedido   = p.id_pedido
 WHERE TO_CHAR(p.fecha_pedido, 'YYYY-MM') = '2026-03'
   AND p.estado <> 'ANULADO'
 GROUP BY c.ciudad
 ORDER BY facturado DESC;


-- #####################################################################
-- LO QUE HAY QUE ENTREGAR
-- #####################################################################
--
-- A. DIAGNÓSTICO  (4 puntos)
--
--    Identifique CUATRO defectos en la secuencia de la PIEZA 1.
--    Para cada uno indique:
--      - qué sentencia o qué parte de la secuencia lo causa
--      - cuál de los tres síntomas del ticket produce
--      - qué pasa en producción con 200 confirmaciones por minuto
--
--    Pista: uno es de concurrencia, uno es de transaccionalidad, uno
--    hace que el problema pase inadvertido, y uno es de rendimiento.
--
--    Para el primero, reprodúzcalo: ejecuten la secuencia desde las DOS
--    conexiones sobre el mismo producto y muestren el resultado.
--
--
-- B. CORRECCIÓN  (4 puntos)
--
--    Reescriba la secuencia usando SQL. Debe cumplir las cuatro cosas:
--      1. que dos confirmaciones simultáneas del mismo producto no
--         puedan perder unidades
--      2. que sea atómica: o se confirma todo el pedido, o nada
--      3. que se note cuando algo no se aplicó, en lugar de pasar en
--         silencio
--      4. que no permita dejar el inventario en negativo
--
--    Debe resolverse con las herramientas que ya vieron hoy:
--      - SELECT ... FOR UPDATE   (parte 1)
--      - UPDATE ... SET col = col - n
--      - MERGE                   (parte 3)
--      - un solo COMMIT al final
--      - la restricción CHECK que ya tiene la tabla INVENTARIO
--
--    Demuéstrelo: ejecute su versión desde las DOS conexiones al mismo
--    tiempo sobre el mismo producto y muestre que el resultado es
--    correcto. Documente cómo lo probó.
--
--
-- C. OPTIMIZACIÓN DE LA CONSULTA  (1 punto)
--
--      - Capture el plan actual y anote COST y consistent gets
--      - Identifique qué impide el uso del índice
--      - Reescriba la consulta y/o cree el índice necesario
--      - Capture el plan nuevo y anote la mejora
--      - Justifique el índice: qué consulta lo usa y por qué no bastaba
--        con los que ya existen
--
--
-- D. UNA RECOMENDACIÓN  (1 punto)
--
--    En un párrafo: ¿qué le diría al jefe de Operaciones para que este
--    problema no vuelva a aparecer? No hable de esta consulta ni de
--    estas sentencias: hable de la práctica que hay que cambiar.
--
--
-- FORMATO DE ENTREGA
--   Un archivo .sql con la secuencia corregida y la consulta optimizada,
--   más un documento corto con las respuestas a A y D y las capturas de
--   los planes de ejecución del punto C.
-- #####################################################################


-- ---------------------------------------------------------------------
-- Zona de trabajo: escriba aquí su versión corregida
-- ---------------------------------------------------------------------

-- Sugerencia de estructura, para que no se pierdan:
--
--   1. Bloquee primero las filas de inventario que va a tocar,
--      SIEMPRE en el mismo orden.
--   2. Descuente el inventario con UNA sola sentencia de conjunto.
--   3. Marque el pedido.
--   4. Revise cuántas filas afectó cada sentencia antes de confirmar.
--   5. Un solo COMMIT al final; si algo salió mal, ROLLBACK.
